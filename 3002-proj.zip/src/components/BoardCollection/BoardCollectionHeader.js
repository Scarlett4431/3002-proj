import React from 'react';

export default function BoardCollectionHeader() {
  return <h2 className="text-2xl mb-4 text-center">YOUR BOARDS</h2>;
}